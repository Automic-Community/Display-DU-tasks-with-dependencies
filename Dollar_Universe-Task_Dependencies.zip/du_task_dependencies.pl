### =============================================================================== ###
### This script output list of task and the dependant objects                       ###
### Argument list                                                                   ###
### - 1: Area: APP, SIM, INT, EXP                                                   ###
### - 1: Nodes (optional, can contain wildcards *)                                  ###
### =============================================================================== ###

### =============================================================================== ###
### Lib required ###


### =============================================================================== ###
### Parameters ###
my $nb_arg=scalar @ARGV;
if ($nb_arg==0) {
    error_arguments();
}
my $AREA_FILTER = $ARGV[0];

my $NODE_FILTER = "";
if ($nb_arg>1) {
    $NODE_FILTER = "node=".$ARGV[1];
}

### =============================================================================== ###
### Main procedure ###

### Execute the command

# Get the list of tasks
open(STDERR, ">err.log");
my $TSK_LIST = `$ENV{'UXEXE'}/uxshw TSK $AREA_FILTER MU=* UPR=* SES=* $NODE_FILTER  vupr=* vses=*`;
my @TSK_LIST = split('\n', $TSK_LIST);

### Parse the list of tasks
my $CUR_TASK_MU = "";
my $CUR_TASK_SES = "";
my $CUR_TASK_UPR = "";
my $CUR_TASK_RULE = "";
print("\n");
foreach my $LINE (@TSK_LIST) {
    # Task
    if (index($LINE,"TYPE  | tsk")>-1) {
        # Display the previous line
        if (length($CUR_TASK_UPR)>0) {
            display_task($CUR_TASK_MU,$CUR_TASK_SES,$CUR_TASK_UPR,$CUR_TASK_RULE);
            $CUR_TASK_MU = "";
            $CUR_TASK_SES = "";
            $CUR_TASK_UPR = "";
            $CUR_TASK_RULE = "";
        }
        # Object: type
        my @TMP = split(':', $LINE);
        $TMP=@TMP[1];
        $TMP =~ s/ //g;
        if ($TMP="upr") {
            $CMD_BUFFER = "uxadd upr";
        }
    # Task Session
    } elsif (index($LINE,"| ses ")>-1) {
        my @TMP = split(':', $LINE);
        $TMP = @TMP[1];
        $TMP =~ s/ //g;
        if (length($TMP)>0) {
            $CUR_TASK_SES = $TMP;
        }
    # Task Uproc
    } elsif (index($LINE,"| upr ")>-1) {
        my @TMP = split(':', $LINE);
        $TMP = @TMP[1];
        $TMP =~ s/ //g;
        if (length($TMP)>0) {
            $CUR_TASK_UPR = $TMP;
        }
    # Task MU
    } elsif (index($LINE,"| mu ")>-1) {
        my @TMP = split(':', $LINE);
        $TMP = @TMP[1];
        $TMP =~ s/ //g;
        if (length($TMP)>0) {
            $CUR_TASK_MU = $TMP;
        }
    # Task Rule
    } elsif (index($LINE,"| rule ")>-1) {
        my @TMP = split(':', $LINE);
        $TMP = @TMP[1];
        $TMP =~ s/ //g;
        if (length($TMP)>0) {
            $CUR_TASK_RULE = $TMP;
        }
    # Default attribute
    } elsif (index($LINE,"| ")>-1) {
        # Do nothing
    # DEBUG
    } else {
        # print($LINE."\n");
    }
}
# Display the previous line
if (length($CUR_TASK_UPR)>0) {
    display_task($CUR_TASK_MU,$CUR_TASK_SES,$CUR_TASK_UPR,$CUR_TASK_RULE);
}
print("\n");

### =============================================================================== ###
### Functions ###

## Exit in error because not the right script arguments
sub error_arguments {
    print("Error: incorrect argment\n");
    print("  Expected argument: <AREA> <TARGET NODE>\n");
    print("  <AREA>: APP, INT, SIM, EXP\n");
    print("  <NODE> (Optional): Node to list the object from\n");
    exit 1;
}

## Display a task
# Parameters
# 1- mu
# 2- ses
# 3- upr
# 4- rul
sub display_task {
    # Parameters
    my $mu   = $_[0];
    my $ses  = $_[1];
    my $upr  = $_[2];
    my $rul  = $_[3];
    # Display if the task
    my $display = $mu." | ".$rul." | ".$ses." | ";
    print( $display );
    # Padding
    my $padding = "";
    for ($i=0;$i<length($display);$i++) {
        $padding .= " ";
    }
    # Task with session or upr
    if (length($ses)>0) {
        # Session
        display_session($ses,$padding);
    } else {
        print($upr);
        display_uproc_command($upr);
    }
    print("\n");
}

## Display a uproc command
# Parameters
# 1- uproc
# 4- padding
sub display_session {
    # Parameters
    my $p_ses  = $_[0];
    my $p_pad  = $_[1];
    # Get the session
    my $SES_DETAIL = `$ENV{'UXEXE'}/uxshw SES $AREA_FILTER SES=$p_ses $NODE_FILTER`;
    my @SES_DETAIL = split('\n', $SES_DETAIL);
    my $lines = 0;
    foreach my $LINE (@SES_DETAIL) {
        # Uproc
        if (index($LINE,"| upr ")>-1) {
            # Padding
            $lines++;
            if ($lines>1) {
                print($p_pad);
            }
            # Uproc
            my @TMP = split(':', $LINE);
            $TMP = @TMP[1];
            $TMP =~ s/ //g;
            print($TMP);
            display_uproc_command($TMP);
        }
    }
}

## Display a uproc command
# Parameters
# 1- uproc
sub display_uproc_command {
    # Parameters
    my $pp_upr = $_[0];
    # Get the session
    print(" | ");
    my $UPR_DETAIL = `$ENV{'UXEXE'}/uxshw UPR $AREA_FILTER UPR=$pp_upr $NODE_FILTER`;
    my @UPR_DETAIL = split('\n', $UPR_DETAIL);
    my $COMMAND = "";
    foreach my $LINE (@UPR_DETAIL) {
        # Script
        if (index($LINE,"| clfil ")>-1) {
            my @TMP = split(':', $LINE);
            $TMP = @TMP[1];
            $TMP =~ s/ //g;
            if (length($TMP)>0) {
                $COMMAND = $TMP;
            }
        # Command
        } elsif (index($LINE,"| command ")>-1) {
            my @TMP = split(':', $LINE);
            $TMP = @TMP[1];
            $TMP =~ s/ //g;
            if (length($TMP)>0) {
                $COMMAND = $TMP;
            }
        # Uproc type
        } elsif (index($LINE,"| upt ")>-1) {
            my @TMP = split(':', $LINE);
            $TMP = @TMP[1];
            $TMP =~ s/ //g;
            if (length($TMP)>0) {
                print("(type: ".$TMP.") ");
            }
        }
    }
    print($COMMAND."\n");
}
